﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.CompilerServices;

namespace _0129
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //1. készítsünk egy olyan tömblistát amely 10 db elemből áll (felhasználó által)
            //először egy számot aztán stringet kér
            //a: olvasd ki az egész array listet
            //b: elemezzük ki hogy hány páros és hány páratlan érték volt
            /*
            ArrayList sorlista = new ArrayList();
            ArrayList sorlista2 = new ArrayList();

            for (int i = 0; i < 10; i++) {

                string str = "";
                int szam = 0;

                if (i % 2 !=0)
                {
                    Console.WriteLine("Kérem a stringet:");
                    str = Console.ReadLine();
                    sorlista.Add(str);
                }
                else
                {
                    Console.WriteLine("Kérem a számot:");
                    szam = int.Parse(Console.ReadLine());
                    sorlista.Add(szam);
                }
                
            
            
            }


            int paros = 0;
            int paratlan = 0;

            for ( int i = 0;i < sorlista.Count;i+=2) {

                sorlista2.Add(sorlista[i]);

            }

            foreach (int i in sorlista2) {

                if (i %2 == 0) { paros++; }
                else { paratlan++; }

            }


            Console.WriteLine("Páros: {0}",paros);
            Console.WriteLine("Páratlan: {0}",paratlan);

            */





            //2. szamok.txt : 1-100 minden 3. számot kiíratni

            StreamWriter writer1 = new StreamWriter("szamok.txt");

            for (int i = 1; i <= 100; i+=3) { 
            
                writer1.WriteLine(i);
                
            }

            writer1.Flush();
            writer1.Close();


            StreamWriter writer2 = new StreamWriter("autok.txt");

            Dictionary<string, int> szotar = new Dictionary<string, int>()
            {

                {"Audi", 2002 },
                {"BMW", 2003 },
                {"Toyota", 2008 },
                {"Hyundai", 1993 },
                {"Alfa Romeo", 2012 },
                {"Dacia", 1998 },
                {"Opel", 2020 },
                {"Suzuki", 2015 },
                {"Volkswagen", 1986 },
                {"Skoda", 2023 }

            };

            foreach (KeyValuePair<string, int> s in szotar)
            {
                writer2.WriteLine("{0}: {1}",s.Key, s.Value);
            }
            writer2.Flush();
            writer2.Close();




            try
            {

                StreamReader reader1 = new StreamReader("gyak.txt");
                List<string> nevek = new List<string>();

                while (!reader1.EndOfStream)
                {
                    nevek.Add(reader1.ReadLine());
                }

                foreach (string i in nevek)
                {
                    Console.WriteLine(i);
                }
                reader1.Close();

            }
            catch (FileNotFoundException) { Console.WriteLine("Nem található a fájl!!!!!!!!"); }
            catch (IOException) { Console.WriteLine("Hibázás van!!!!!!!!"); }





















            Console.ReadKey();

        }
    }
}
