<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Index</title>
</head>

<body class="bg-info">


<div class="container mt-4 w-50 p-3">
        <h2>Rekord lista:</h2>
        <br>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Cím</th>
                    <th scope="col">Sorszám</th>
                    <th scope="col">kategória</th>

                </tr>
            </thead>
            <tbody>
                <?php require('betoltes.php');

                    $tabla = "CREATE TABLE IF NOT EXISTS kazetta(
                    id int PRIMARY KEY AUTO_INCREMENT,
                    cim varchar(100)  NOT NULL,
                    sorszam int(10)  NOT NULL,
                    kategoria varchar(100)  NOT NULL
                
                );";

                $stmt_prepare = mysqli_prepare($conn, $tabla);
                mysqli_stmt_execute($stmt_prepare);

                leker();
                ?>
            </tbody>
        </table>
    </div>


</body>
</html>
