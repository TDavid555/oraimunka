<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Insert data</title>
</head>

<body>
    <?php

    include "kapcsolat.php";

    $tabla = "CREATE TABLE IF NOT EXISTS kazetta(

    id int PRIMARY KEY AUTO_INCREMENT,
    cim varchar(100)  NOT NULL,
    sorszam int(10)  NOT NULL,
    kategoria varchar(100)  NOT NULL

);";

    $stmt_prepare = mysqli_prepare($conn, $tabla);
    mysqli_stmt_execute($stmt_prepare);

    if (check_fields()) {
        kazetta_create();
    }

    function check_fields()
    {
        $cim = isset($_POST["cim"]) && !empty($_POST["cim"]);
        $sorszam = isset($_POST["sorszam"]) && !empty($_POST["sorszam"]);
        $kategoria = isset($_POST["kategoria"]) && !empty($_POST["kategoria"]);
        return $cim &&  $sorszam && $kategoria;
    }

    function kazetta_create()
    {
        global $conn;
        $cim = $_REQUEST["cim"];
        $sorszam = $_REQUEST["sorszam"];
        $kategoria = $_REQUEST["kategoria"];

        $stmt = "INSERT INTO kazetta (cim,sorszam,kategoria) VALUES ('$cim', $sorszam, '$kategoria')";
        $stmt_prepare2 = mysqli_prepare($conn, $stmt);
        mysqli_stmt_execute($stmt_prepare2);
    }


    ?>

    <h1>A módosítás megtörtént</h1>

    <a href="index.php"><button class="btn btn-success">Vissza a főoldalra</button></a>


    



</body>

</html>