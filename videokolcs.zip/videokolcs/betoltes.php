<?php

include "kapcsolat.php";



function kazetta_read_all()
    {

        global $conn;
        $lekeres = mysqli_query($conn, "SELECT * FROM kazetta");


        while ($tabla = mysqli_fetch_array($lekeres)) {
            $table_row = <<<KAZETTA
            <tr>
                <td>{$tabla['id']}</td>
                <td>{$tabla['cim']}</td>
                <td>{$tabla['sorszam']}</td>
                <td>{$tabla['kategoria']}</td>
                
                
            </tr>
            KAZETTA;
            echo $table_row;
        }
    }

    function leker(){
        global $conn;
        $valtozo = $_POST["query"];
        $mufaj1 = mysqli_query($conn, "SELECT * FROM kazetta WHERE kategoria='$valtozo';");
        
        while ($tabla = mysqli_fetch_array($mufaj1)) {
            $table_row = <<<KAZETTA
            <tr>
                <td>{$tabla['id']}</td>
                <td>{$tabla['cim']}</td>
                <td>{$tabla['sorszam']}</td>
                <td>{$tabla['kategoria']}</td>
                
                
            </tr>
            KAZETTA;
            echo $table_row;
        }
    }

