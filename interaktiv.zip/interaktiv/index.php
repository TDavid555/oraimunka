<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Index</title>
</head>

<body class="bg-warning">
    <h1 class="text-center">Admin felület</h1>


    <div class="container mt-4 w-50 p-3">
        <h2>Új rekord felvétele</h2>
        <br>
        <form action="insert.php" method="post">

            <label for="nev">Név</label>
            <input type="text" name="nev" class="form-control form-control-lg" placeholder="Kérem a neved...">

            <label for="email">Email</label>
            <input type="email" name="email" class="form-control form-control-lg" placeholder="Kérem az email címed...">

            <label for="password">Password</label>
            <input type="password" name="password" class="form-control form-control-lg" placeholder="Kérem a jelszavad...">

            <input type="submit" value="Küldés" class="btn btn-success mt-4">

        </form>
    </div>

    <br>

    <div class="container mt-4 w-50 p-3">
        <h2>Rekord törlése</h2>
        <br>
        <form action="delete_user.php" method="get">

            <label for="nev">Név alapján:</label>
            <input type="text" name="nev" class="form-control form-control-lg" placeholder="Kérem az nevet...">


            <input type="submit" value="Törlés" class="btn btn-danger mt-4">



        </form>
    </div>

    <br>

    <div class="container mt-4 w-50 p-3">
        <h2>Rekord módosítása</h2>
        <br>
        <form action="edit_user.php" method="get">

            <label for="nev">Név</label>
            <input type="text" name="nev" class="form-control form-control-lg" placeholder="Kérem a régi nevet...">

            <label for="uj_nev">Új Név</label>
            <input type="text" name="uj_nev" class="form-control form-control-lg" placeholder="Kérem az új nevet...">


            <input type="submit" value="Update" class="btn btn-success mt-4">


        </form>
    </div>


    <div class="container mt-4 w-50 p-3">
        <h2>Rekord lista:</h2>
        <br>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Azonosító</th>
                    <th scope="col">Név</th>
                    <th scope="col">Email</th>
                    <th scope="col">Jelszó</th>

                </tr>
            </thead>
            <tbody>
                <?php require('betoltes.php');
                user_read_all();
                ?>
            </tbody>
        </table>
    </div>
    <br>






</body>

</html>