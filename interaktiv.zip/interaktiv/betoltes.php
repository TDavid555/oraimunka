<?php

include "kapcsolat.php";



function user_read_all()
    {

        global $conn;
        $lekeres = mysqli_query($conn, "SELECT * FROM users");


        while ($user = mysqli_fetch_array($lekeres)) {
            $table_row = <<<USERS
            <tr>
                <td>{$user['id']}</td>
                <td>{$user['nev']}</td>
                <td>{$user['email']}</td>
                <td>{$user['password']}</td>
                
                
            </tr>
            USERS;
            echo $table_row;
        }
    }
