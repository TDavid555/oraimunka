﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0415
{
    public partial class Form1 : Form
    {
        List<int> szamok = new List<int>(5);
        public Form1()
        {
            InitializeComponent();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            if (szamok.Count != 5)
            {

                int szam = int.Parse(textBox1.Text);
                szamok.Add(szam);
                textBox1.Clear();

                listBox1.Items.Clear();
                for (int i = 0; i < szamok.Count; i++)
                {
                    listBox1.Items.Add(szamok[i]);
                }
            }
            else
            {
                button1.Enabled = false;
                textBox1.Enabled = false;
            }
            szamok.Sort();
            for (int i = 0; i < szamok.Count; i++)
            {
                listBox3.Items.Add(szamok[i]);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            int keresi = int.Parse(textBox2.Text);

            
            
            
            if(szamok[szamok.Count/2] == keresi)
            {
                listBox2.Items.Add(szamok.Count/2+1);
            }

            if (szamok[szamok.Count / 2] > keresi)
            {
                for (int i = 0;i < szamok.Count/2; i++)
                {
                    if (szamok[i]==keresi)
                    {
                        listBox2.Items.Add(i+1);
                    }
                }
            }

            if (szamok[szamok.Count / 2] < keresi)
            {
                for (int i = szamok.Count/2+1; i < szamok.Count; i++)
                {
                    if (szamok[i] == keresi)
                    {
                        listBox2.Items.Add(i+1);
                    }
                }
            }


        }
    }
}
