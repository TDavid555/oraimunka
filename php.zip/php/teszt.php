<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teszt";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$nev = $_POST['nev'];
$lakcim = $_POST['lakcim'];
$szul = $_POST['szul'];

$sql = "INSERT INTO emberek (nev, lakcim, szul)
VALUES ('$nev', '$lakcim', '$szul')";

mysqli_query($conn,$sql);




$conn->close();
?>