document.getElementById("ell").addEventListener("click", function () {
    var egysegar = parseFloat(document.getElementById("egysegar").value);
    var ossztav = parseFloat(document.getElementById("ossztav").value);
    var fogyNorma = document.getElementById("normak").value;

    if (isNaN(egysegar) || isNaN(ossztav) || fogyNorma == "") {
        alert("Tölts ki mindent!");
        return;
    }

    var fogyNorma_ar = fogyNorma.split(" ");
    var norma_mennyiseg = parseFloat(fogyNorma_ar[0]);
    var normaEgyseg = fogyNorma_ar[fogyNorma_ar.length - 1];

    if (normaEgyseg === "l/100km") {
        norma_mennyiseg = norma_mennyiseg / 100;
    }

    var utikoltseg = norma_mennyiseg * ossztav * egysegar / 100;
    var amortizacio = ossztav * 15;
    var osszeg = utikoltseg + amortizacio;

    document.getElementById("utikoltseg").textContent = "Útiköltség: " + utikoltseg.toFixed() + " Ft";
    document.getElementById("amortizacio").textContent = "Amortizáció: " + amortizacio.toFixed() + " Ft";
    document.getElementById("vegosszeg").textContent = "Összesen elszámolható költség: " + osszeg.toFixed() + " Ft";
});

function FogyNorma() {
    var uzemanyagSelect = document.getElementById("uzemanyagok");
    var fogyNormaSelect = document.getElementById("normak");

    fogyNormaSelect.innerHTML = "";

    if (uzemanyagSelect.value == "Benzin") {
        hozzaad(fogyNormaSelect, "1000 cm3-ig 7,6 l/100km");
        hozzaad(fogyNormaSelect, "1001-1500 cm3 között 8,6 l/100km");
        hozzaad(fogyNormaSelect, "1501-2000 cm3 között 9,5 l/100km");
        hozzaad(fogyNormaSelect, "2001-3000 cm3 között 11,4 l/100km");
        hozzaad(fogyNormaSelect, "3001 cm3 fölött 13,3 l/100km");
        
    } else if (uzemanyagSelect.value == "Gazolaj") {
        hozzaad(fogyNormaSelect, "1500 cm3-ig 5,7 l/100km");
        hozzaad(fogyNormaSelect, "1501-2000 cm3 között 6,7 l/100km");
        hozzaad(fogyNormaSelect, "2001-3000 cm3 között 7,6 l/100km");
        hozzaad(fogyNormaSelect, "3001 cm3 fölött 9,5 l/100km");
    }
}

function hozzaad(selectElement, optionText) {
    var option = document.createElement("option");
    option.value = optionText;
    option.text = optionText;
    selectElement.add(option);
}