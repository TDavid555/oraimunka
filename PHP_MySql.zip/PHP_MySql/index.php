<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Index</title>
</head>

<body class="bg-primary">
    <h1 class="text-center">Admin felület</h1>
    <div class="container mt-4 w-50 p-3">
        <form action="insert.php" method="post">

            <label for="nev">Név</label>
            <input type="text" name="nev" class="form-control form-control-lg"  placeholder="Kérem a neved...">

            <label for="email">Email</label>
            <input type="email" name="email" class="form-control form-control-lg"  placeholder="Kérem az email címed...">

            <label for="password">Password</label>
            <input type="password" name="password" class="form-control form-control-lg"  placeholder="Kérem a jelszavad...">

            <input type="submit" value="Küldés" class="btn btn-success mt-4">

        </form>
    </div>
    <div class="container mt-4 w-50 p-3"> 
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Azonosító</th>
                        <th scope="col">Név</th>
                        <th scope="col">Email</th>
                        <th scope="col">Jelszó</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php include('insert.php'); user_read_all();mysqli_close($conn)?>
                </tbody>
            </table>
        </div>
</body>

</html>