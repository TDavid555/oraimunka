<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert data</title>
</head>

<body>
    <?php
    $databaseHost = '127.0.0.1';
    $databaseUsername = 'root';
    $databasePassword = '';
    $databaseName = 'adatbazis';


    $conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);



    mysqli_set_charset($conn, 'utf8');

    $tabla = "CREATE TABLE IF NOT EXISTS users(

    id int PRIMARY KEY AUTO_INCREMENT,
    nev varchar(100)  NOT NULL,
    email varchar(100)  NOT NULL,
    password varchar(100)  NOT NULL



);";

    $stmt_prepare = mysqli_prepare($conn, $tabla);
    mysqli_stmt_execute($stmt_prepare);

    if (check_fields()) {
        user_create();
    }

    function check_fields()
    {
        $nev = isset($_POST["nev"]) && !empty($_POST["nev"]);
        $email = isset($_POST["email"]) && !empty($_POST["email"]);
        $password = isset($_POST["password"]) && !empty($_POST["password"]);
        return $nev &&  $email && $password;
    }

    function user_create()
    {
        global $conn;
        $nev = $_REQUEST["nev"];
        $email = $_REQUEST["email"];
        $password = $_REQUEST["password"];

        $stmt = "INSERT INTO users (nev,email,password) VALUES ('$nev', '$email', '$password')";
        $stmt_prepare2 = mysqli_prepare($conn, $stmt);
        mysqli_stmt_execute($stmt_prepare2);
    }

    function user_read_all()
    {
        global $conn;
        $lekeres = mysqli_query($conn,"SELECT * FROM users");

       
        while ($user = mysqli_fetch_array($lekeres)) {
            $table_row = <<<USERS
            <tr>
                <td>{$user['id']}</td>
                <td>{$user['nev']}</td>
                <td>{$user['email']}</td>
                <td>{$user['password']}</td>
                
                <td>
                    
                </td>
            </tr>
            USERS;
            echo $table_row;
        }
    }



    //mysqli_close($conn);
    ?>

    <!--
    <button class="btn btn-outlines-success" onclick="location.href='index.php'" >Vissza a főoldalra</button>

    -->
</body>

</html>